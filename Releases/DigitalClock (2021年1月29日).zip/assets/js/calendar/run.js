var events = [
];
var settings = {
	NavShow: false,
};
var element = document.getElementById('caleandar');
caleandar(element, events, settings);
