# BingWallPaperMaster

### 高考倒计时

* [x] 2021高考倒计时，可拓展自定义时间
* [x] 当前日期及时间
参考：[Sanksu Countdowm-NMET](https://github.com/Sanksu/Countdowm-NMET)

### [必应(Bing)](www.bing.com)每日背景图片获取

* [x] 每日自动更换背景图片
* [x] Wallpaper Engine支持

**调用到的api**
<https://hitokoto.cn/>
<https://www.jinrishici.com/>
